const express = require("express");
const Rooms = require("../models/ChatRooms")
const User = require("../models/UserSchema");
exports.createNewRoom = async(req,res)=>{
    try {
        /*
            1. First grab the creator 
            2. grab the name,description fileds from body
            3. validate it and store

        */
       const roomObj = {};
       const{name,description} = req.body;
       if(!name || !description){return res.send('Please provide all the fields')}
       else{
            roomObj.name = name;
            roomObj.description = description;
            
            let currentUser = await User.findOne({_id : req.user.id});
            const userName = currentUser.name;
            roomObj.creator = req.user.id;
            roomObj.creatorName = userName;
            const room = new Rooms(roomObj);
            await room.save();
            res.json(room);
       }
    } catch (error) {
        console.log('Server Error : ',error.message)
        res.send('Server Error')
    }
}


//get room details by id
exports.getRoomDetails = async(req,res)=>{
    try {
       
        const isPresent = await Rooms.findOne({_id : req.params.roomId});
        if(!isPresent){return res.send('No room is existed with this id')}
        else{
            return res.json(isPresent)
        }
       
    } catch (error) {
        console.log('Server Error : ',error.message)
        res.send('Server Error')
    }
}



//update the room details by id
exports.updateRoomDetails = async(req,res)=>{
    try{
        const presetRoomId = req.params.roomId;

        
        const{name,description} = req.body;
        // grab the name, description
        const updateRoomObj = {};
        if(name){
            updateRoomObj.name = name;
        }
        if(description){
            updateRoomObj.description = description;
        }
        //now update the room
        const room = await Rooms.findOneAndUpdate({_id : presetRoomId} ,{$set : updateRoomObj},{new : true});
        await room.save();
        res.json({
            message : 'Your room detials are updated',
            data : room
        })
    } catch (error) {
        console.log('Server Error : ',error.message)
        res.send('Server Error')
    }
}


//delete the room by id
exports.deleteChatRoom = async(req,res)=>{
    try {
        const presetRoomId = req.params.roomId;
        const room = await Rooms.findOneAndDelete({_id : presetRoomId});

        if(!room){return res.send('No room found')}
        else{
            res.json('Your room is deleted')
        }
    } catch (error) {
        console.log('Server Error : ',error.message)
        res.send('Server Error')
    }
    }
