const mongoose = require("mongoose");

const ChatRooms = new mongoose.Schema({
    creator :{
        type: mongoose.Types.ObjectId,
        ref :'user',
    },
    creatorName :{type:String,required:true},
    name:{
        type:String,
        required:true
    },
    description:{
        type:String,
        required:true
    },
    createdAt:{
        type : Date,
        default : Date.now
    },
    members:[
        {
            user:{type:mongoose.Types.ObjectId}
        }
    ],
    chats:[

        {
            user : {type:mongoose.Types.ObjectId},
            message :{type : String}
        }
    ],
    
});

module.exports = Room = mongoose.model("room",ChatRooms);