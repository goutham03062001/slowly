const express = require("express");
const router = express.Router();
const rooms = require("../controllers/rooms");
const auth = require("../middlewares/auth")
// router.get("/", rooms.createNewRoom);

//@route    POST /new
//@desc     create a new room
//@access   Private
router.post("/new",auth, rooms.createNewRoom)


//@route    GET /:roomId
//@desc     get a room by id
//@access   Private
router.get("/:roomId",auth, rooms.getRoomDetails)



//@route    PUT/:roomId
//@desc     update the room by id
//@access   Private
router.put("/:roomId",auth, rooms.updateRoomDetails)



//@route    DELETE/:roomId
//@desc     delete the room by id
//@access   Private
router.delete("/:roomId",auth, rooms.deleteChatRoom)
module.exports = router;